import csv
import os
from matplotlib import pyplot as plt
import numpy as np

loop = True

while loop:
	print(
	'''
	1. Visualize tweets by keyword
	2. Exit
	'''
	)
	user_input = input('Your input: ')
	if int(user_input) == 1:
		if os.path.isfile('./key1.csv' and './key2.csv' and './key3.csv'):
			#########   v1, v2, v3 is Positive degree each Day
			with open('key1.csv', 'r') as key1_file:
				reader = csv.DictReader(key1_file)
				for each_row in reader:
					v1 = float(each_row['Positive_Tweets'])
					company_name = each_row['Keyword']        #apple, Disney....

			with open('key2.csv', 'r') as key2_file:
				reader = csv.DictReader(key2_file)
				for each_row in reader:
					
					v2 = float(each_row['Positive_Tweets'])

			with open('key3.csv', 'r') as key3_file:
				reader = csv.DictReader(key3_file)
				for each_row in reader:
					v3 = float(each_row['Positive_Tweets'])

			labels = ('16 ~ 17', '18 ~ 19', '20 ~ 21')
			x_pos = np.arange(len(labels))
			types_of_tweets = [ v1, v2, v3 ]
			plt.plot(x_pos, types_of_tweets, 'Red')
			plt.xticks(x_pos, labels)
			plt.ylabel("Positive Scale")
			plt.title(company_name)
			plt.show()
		else:
			print('Input files do not exist')
	elif int(user_input) == 2:
		loop = False
	else:
		print('Please enter 1 or 2')

	